package edu.upenn.cis455.mapreduce.master;

public class WorkerStatus {

	public String ip;
	public int port;
	public String status;
	public String job;
	public int keys_read;
	public int keys_written;
	public long last_received;
	
	public WorkerStatus() {
		ip = "";
		port = 0;
		status = "";
		job = "";
		keys_read = 0;
		keys_written = 0;
	}
	
}
