rm -rf /home/cis455/Documents/tomcat1/webapps/master
rm /home/cis455/Documents/tomcat1/webapps/master.war
cp master.war /home/cis455/Documents/tomcat1/webapps
sh /home/cis455/Documents/tomcat1/bin/catalina.sh run
