rm -rf /home/cis455/Documents/tomcat3/webapps/worker
rm /home/cis455/Documents/tomcat3/webapps/worker.war
cp worker.war /home/cis455/Documents/tomcat3/webapps
sh /home/cis455/Documents/tomcat3/bin/catalina.sh run
