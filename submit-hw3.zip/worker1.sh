rm -rf /home/cis455/Documents/tomcat2/webapps/worker
rm /home/cis455/Documents/tomcat2/webapps/worker.war
cp worker.war /home/cis455/Documents/tomcat2/webapps
sh /home/cis455/Documents/tomcat2/bin/catalina.sh run
